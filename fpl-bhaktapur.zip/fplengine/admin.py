from django.contrib import admin

from django.contrib import admin
from .models import  *

admin.site.register(Company)
admin.site.register(ClassicLeague)
admin.site.register(DivisionLeague)
admin.site.register(Division)
admin.site.register(DivisionGameweekWinner)
DivisionGameweekWinner
admin.site.register(Teams)
admin.site.register(Gameweek)
admin.site.register(Gameweekwinner)
admin.site.register(Winner)
admin.site.register(IamSafe)