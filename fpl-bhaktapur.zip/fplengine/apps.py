from django.apps import AppConfig


class AryanConfig(AppConfig):
    name = 'fplengine'
